from chatterbot import ChatBot
from chatterbot.trainers import ChatterBotCorpusTrainer
from flask import Flask, render_template, request
import os.path

# Create a new chat bot named AITA
chatbot = ChatBot("AITA")

#enable the following code to delete trained data
#chatbot.storage.drop()

trainer = ChatterBotCorpusTrainer(chatbot)

#initial training set
trainer.train(
        "chatterbot.corpus.custom.demodata"
)
dirname = 'C:\\Users\\palakpatel\\Chat\\chatterbot-corpus-1.1.2\\chatterbot_corpus\\data\\english'

for filename in os.listdir(dirname):
    with open(os.path.join(dirname, filename), "rt") as f:
        data = f.readlines()
    bot.train(data)
#control script to control when to end the session
i = 1
while i < 2:
    question = input("Ask away:");
    if question == "Exit":
        i=3
    else:
        response = chatbot.get_response(question)
        print(response)


app = Flask(__name__)

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/post', methods=['POST'])
def post():
    return "recived: {}".format(request.form)

if __name__ == "__main__":
    app.run(debug=True)
